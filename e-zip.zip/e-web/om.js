document.addEventListener('DOMContentLoaded', function() {
    const bar = document.getElementById('bar');
    const close = document.getElementById('close');
    const nav = document.getElementById('navbar');

    if (bar) {
      bar.addEventListener('click', () => {
        nav.classList.add('active');
      });
    }

    if (close) {
      close.addEventListener('click', () => {
        nav.classList.remove('active');
      });
    }
  });

  // Retrieve the selected product information from local storage
  const selectedProduct = JSON.parse(localStorage.getItem('selectedProduct'));

  // Generate a table row with the selected product information
  function generateTableRow(product) {
    const tr = document.createElement('tr');
    const nameTd = document.createElement('td');
    const brandTd = document.createElement('td');
    const priceTd = document.createElement('td');

    nameTd.textContent = product.name;
    brandTd.textContent = product.brand;
    priceTd.textContent = '$' + product.price;

    tr.appendChild(nameTd);
    tr.appendChild(brandTd);
    tr.appendChild(priceTd);

    return tr;
  }

 
  // Function to remove a row from the cart
  function removeRow(element) {
    var row = element.closest('tr');
    row.remove();
  }